import React from 'react'

const Footer = () => {
  return (
    <div className='text-bg-dark text-center p-5 container-fluid'>
      <p> &copy; Designed and Developed By Akhila</p>
    </div>
  )
}

export default Footer
